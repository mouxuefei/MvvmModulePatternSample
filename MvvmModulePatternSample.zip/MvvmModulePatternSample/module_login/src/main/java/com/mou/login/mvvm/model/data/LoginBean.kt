package com.mou.login.mvvm.model.data

/**
 * @FileName: LoginBean.java
 * @author: villa_mou
 * @date: 06-16:19
 * @version V1.0 <描述当前版本功能>
 * @desc
 */
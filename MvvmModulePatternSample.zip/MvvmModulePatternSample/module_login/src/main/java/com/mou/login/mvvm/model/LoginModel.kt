package com.mou.login.mvvm.model

import com.mou.basemvvm.mvvm.BaseModel

/**
 * @FileName: LoginModel.java
 * @author: villa_mou
 * @date: 08-11:09
 * @version V1.0 <描述当前版本功能>
 * @desc
 */
class LoginModel:BaseModel() {
}
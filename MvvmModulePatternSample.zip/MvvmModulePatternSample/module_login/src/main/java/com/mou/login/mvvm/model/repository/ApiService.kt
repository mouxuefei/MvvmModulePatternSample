package com.mou.login.mvvm.model.repository

/**
 */

interface ApiService {

}

package com.fortunes.commonsdk.view.photoviewer

import android.view.View


interface OnLongClickListener{
    fun onLongClick(view: View)
}

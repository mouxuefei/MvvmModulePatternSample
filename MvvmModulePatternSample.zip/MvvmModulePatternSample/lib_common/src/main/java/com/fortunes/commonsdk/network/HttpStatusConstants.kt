package com.fortunes.commonsdk.network

/**
 * @auther:MR-Cheng
 * @date: 2018/12/4
 * @description: 网络请求code对照表
 * @parameter:
 */

object HttpStatusConstants {
    const val SUCCESS = 0
}
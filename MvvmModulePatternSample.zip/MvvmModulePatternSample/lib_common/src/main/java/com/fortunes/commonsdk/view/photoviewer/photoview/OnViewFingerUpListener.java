package com.fortunes.commonsdk.view.photoviewer.photoview;

/**
 * Created by WangLu on 2018/7/15.
 */

public interface OnViewFingerUpListener {
    void onViewFingerUp();
}

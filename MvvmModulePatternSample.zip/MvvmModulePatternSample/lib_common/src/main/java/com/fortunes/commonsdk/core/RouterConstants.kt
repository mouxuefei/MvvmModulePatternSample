package com.fortunes.commonsdk.core

/***
 * You may think you know what the following code does.
 * But you dont. Trust me.
 * Fiddle with it, and youll spend many a sleepless
 * night cursing the moment you thought youd be clever
 * enough to "optimize" the code below.
 * Now close this file and go play with something else.
 */
/***
 *
 *   █████▒█    ██  ▄████▄   ██ ▄█▀       ██████╗ ██╗   ██╗ ██████╗
 * ▓██   ▒ ██  ▓██▒▒██▀ ▀█   ██▄█▒        ██╔══██╗██║   ██║██╔════╝
 * ▒████ ░▓██  ▒██░▒▓█    ▄ ▓███▄░        ██████╔╝██║   ██║██║  ███╗
 * ░▓█▒  ░▓▓█  ░██░▒▓▓▄ ▄██▒▓██ █▄        ██╔══██╗██║   ██║██║   ██║
 * ░▒█░   ▒▒█████▓ ▒ ▓███▀ ░▒██▒ █▄       ██████╔╝╚██████╔╝╚██████╔╝
 *  ▒ ░   ░▒▓▒ ▒ ▒ ░ ░▒ ▒  ░▒ ▒▒ ▓▒       ╚═════╝  ╚═════╝  ╚═════╝
 *  ░     ░░▒░ ░ ░   ░  ▒   ░ ░▒ ▒░
 *  ░ ░    ░░░ ░ ░ ░        ░ ░░ ░
 *           ░     ░ ░      ░  ░
 *
 * Created by mou on 2018/9/13.
 */
object RouterConstants {
    private const val HOME = "/home"
    private const val LOGIN = "/login"
    private const val MINE = "/mine"
    private const val WEB = "/web"
    /**
     * 主界面
     */
    const val MAIN_ACTIVITY = "$HOME/MainActivity"
    /**
     * 登录
     */
    const val LOGIN_ACTIVITY = "$LOGIN/loginActivity"
    /**
     * web页面
     */
    const val WEB_ACTIVITY = "$WEB/WebActivity"

    /**
     * 个人中心
     */
    const val MINE_ACTIVITY = "$MINE/MineActivity"
}
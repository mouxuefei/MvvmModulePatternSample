package com.mou.basemvvm.mvvm

/**
 * @FileName: IModel.java
 * @author: villa_mou
 * @date: 08-10:44
 * @version V1.0 <描述当前版本功能>
 * @desc
 */
interface IModel {
}
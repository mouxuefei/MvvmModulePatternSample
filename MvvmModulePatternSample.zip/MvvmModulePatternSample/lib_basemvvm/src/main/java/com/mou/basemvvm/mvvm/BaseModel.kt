package com.mou.basemvvm.mvvm

/**
 * @FileName: BaseModel.java
 * @author: villa_mou
 * @date: 08-10:49
 * @version V1.0 <描述当前版本功能>
 * @desc
 */
abstract class BaseModel:IModel {
}
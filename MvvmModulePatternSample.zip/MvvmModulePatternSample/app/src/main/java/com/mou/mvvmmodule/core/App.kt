package com.mou.mvvmmodule.core

import com.mou.basemvvm.BaseApplication


class App : BaseApplication() {

}